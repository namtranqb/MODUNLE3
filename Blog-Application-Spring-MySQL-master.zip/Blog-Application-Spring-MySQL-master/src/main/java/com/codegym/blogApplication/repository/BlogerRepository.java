package com.codegym.blogApplication.repository;

import com.codegym.blogApplication.model.Bloger;

public interface BlogerRepository extends Repository<Bloger> {
}
